<?php

namespace App\Http\Controllers;

use App\Models\TemporaryImage;
use Illuminate\Http\Request;

class TemporaryImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TemporaryImage  $temporaryImage
     * @return \Illuminate\Http\Response
     */
    public function show(TemporaryImage $temporaryImage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TemporaryImage  $temporaryImage
     * @return \Illuminate\Http\Response
     */
    public function edit(TemporaryImage $temporaryImage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\TemporaryImage  $temporaryImage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TemporaryImage $temporaryImage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TemporaryImage  $temporaryImage
     * @return \Illuminate\Http\Response
     */
    public function destroy(TemporaryImage $temporaryImage)
    {
        //
    }
}
